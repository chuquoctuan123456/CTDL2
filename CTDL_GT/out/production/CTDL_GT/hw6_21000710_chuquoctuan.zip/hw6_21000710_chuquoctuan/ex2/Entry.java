package hw6_21000710_chuquoctuan.ex2;

public interface Entry<K, E> {
    K getKey();

    E getValue();
}

