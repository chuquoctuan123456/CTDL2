package hw6_21000710_chuquoctuan.ex3;

public interface Entry<K, E> {
    K getKey();

    E getValue();
}

