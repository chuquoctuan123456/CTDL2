package hw2_21000710_chuquoctuan.algorithmssort;

public interface SimpleSortingAlgorithm {
    public void sort(int[] array);
    public void sortVersion2(int[] array);

}
